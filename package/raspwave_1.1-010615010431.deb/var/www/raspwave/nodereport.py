#!/usr/bin/env python
# @author rouble matta

import sys
sys.path.append('/etc/raspwave/pylib')
from LoggerUtils import setupSecurityLogger
from NotificationHandler import getNCB,NodeControlBlock
from ConfUtils import getNodes,getNodeName
import cgi, cgitb
cgitb.enable()

logger = setupSecurityLogger()

print 'Content-Type: text/html'
print # HTTP says you have to have a blank line between headers and content
print '<html>'
print '  <head>'
print '    <title> Node Report </title>'
print '  </head>' 
print '  <body>'
print '  <h1> Node Report </h1>'
for nodeId in getNodes():
    ncb = getNCB(nodeId)
    nodeName = getNodeName(nodeId)
    print '<h2>' + nodeName + ' Status</h2>' 
    print '<p> Current State: ' + ncb.state + ' </p>' 
print '      <button onClick="window.location=\'http://irouble.synology.me:8443/raspwave/controlpanel.py\'" style="font: bold 60px Arial">Back to Control Panel</button><br><br>'
print '  </body>'
print '</html>'
