#!/usr/bin/env python
# @author rouble matta

import sys
from CacheUtils import writeStringValue

print writeStringValue(sys.argv[1], sys.argv[2])
