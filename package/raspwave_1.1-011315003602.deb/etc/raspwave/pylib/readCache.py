#!/usr/bin/env python
# @author rouble matta

import sys
from CacheUtils import readStringValue

print readStringValue(sys.argv[1])
