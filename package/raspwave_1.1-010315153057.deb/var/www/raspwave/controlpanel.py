#!/usr/bin/env python
# @author rouble matta

import sys
sys.path.append('/etc/raspwave/pylib')
from SecurityUtils import getCurrentAlarmState,AlarmState
import cgi, cgitb

cgitb.enable()

if __name__ == '__main__':
    print 'Content-Type: text/html'
    print # HTTP says you have to have a blank line between headers and content
    print '<!DOCTYPE html>'
    print '<html>'
    print '  <head>'
    print '    <title> Raspwave Alarm Control Panel </title>'
    print '  </head>'
    print '  <body>'
    print '    <div id="main">'
    print '      <h3> Alarm State </h3>'
    currentAlarmState = getCurrentAlarmState()
    for state in AlarmState:
        color = ""
        if currentAlarmState == state:
            color = "color: red;" 
        print '      <button id="' + state + '" onClick=\'setState("' + state +'")\' style="' + color + 'font: bold 60px Arial">' + state + '</button><br><br>'
        print '      <br><br>'
    print '      <h3> Panic/UnPanic</h3>'
    print '      <button onClick="window.location=\'http://irouble.synology.me:8443/raspwave/panic.py\'" style="font: bold 60px Arial">PANIC</button><br><br>'
    print '      <br><br>'
    print '      <button onClick="window.location=\'http://irouble.synology.me:8443/raspwave/unpanic.py?code=1234\'" style="font: bold 60px Arial">UNPANIC</button><br><br>'
    print '      <br><br>'
    print '      <h3> Detailed Status</h3>'
    print '      <button onClick="window.location=\'http://irouble.synology.me:8443/raspwave/currentstate.py\'" style="font: bold 60px Arial">STATUS</button><br><br>'
    print '      <button onClick="window.location=\'http://irouble.synology.me:8443/raspwave/alarm_status.py\'" style="font: bold 60px Arial">DETAIL STATUS</button><br><br>'
    print '      <button onClick="window.location=\'http://irouble.synology.me:8443/raspwave/report.py\'" style="font: bold 60px Arial">NODE REPORT</button><br><br>'
    print '    </div>'
    print '  <style>'
    print '    html, body {'
    print '      height: 100%;'
    print '      width: 100%;'
    print '    }'
    print '    #main {'
    print '      margin-right: auto         '            
    print '      margin-left: auto         '            
    print '      left: 0;'
    print '      min-height: 100%;'
    print '      width: 100%;'
    print '      position: absolute;'
    print '      overflow: auto;'
    print '    }'
    print '  </style>'
    print '<script>'
    print 'function clearAllButtonColors ()'
    print '{'
    for state in AlarmState:
        print '    document.getElementById("' + state + '").style.color = "black";'
    print '}'
    print 'function setState(state)'
    print '{'
    print '    clearAllButtonColors()'
    print '    document.getElementById(state).style.color = "red";'
    print '    var xmlHttp = null;'
    print '    xmlHttp = new XMLHttpRequest();'
    print '    xmlHttp.open( "GET", "http://irouble.synology.me:8443/raspwave/" + state.toLowerCase() + ".py", false, "alarm", "abcd1234");'
    print '    xmlHttp.send( null );'
    print '    return xmlHttp.responseText;'
    print '}'
    print '</script>'
    print '</html>'
