#!/usr/bin/env python
# @author rouble matta

from strings import writeStringValue

writeStringValue("STATE", "AWAY")
# Might need to turn off any active alarms here
