#!/usr/bin/env python
# @author rouble matta

import sys
from RobotUtils import sendEmail, getNodeName, readStringValue

# Always send an email, regardless of armed state

def processSignalOnSensor(name, state):
    alarm_state = str(readStringValue("STATE"))
    if (state == "open"):
        sendEmail(["rouble@gmail.com"],  "[" + alarm_state + "] " + name + " is open", "hello");
    elif (state == "close") :
        sendEmail(["rouble@gmail.com"], "[" + alarm_state + "] " + name + " is closed", "hello");

def main(id, state):
    processSignalOnSensor(getNodeName(id), state)
    return 0

if __name__=='__main__':
    sys.exit(main(sys.argv[1], sys.argv[2]))
