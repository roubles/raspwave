#!/usr/bin/env python
# @author rouble matta

import sys
import logging
from RobotUtils import sendEmail, getNodeName, readStringValue
from NotificationHandler import Notification,getNodeReport,setupLogger

setupLogger("robots", "/var/log/raspwave/robots.log", True, False)
logger = logging.getLogger("robots")

# Always send an email, regardless of armed state
def processSignalOnSensor(id, state):
    name = getNodeName(id)
    alarm_state = str(readStringValue("STATE"))
    if (state == "open"):
        sendEmail(["rouble@gmail.com"],  "[" + alarm_state + "] " + name + " is open", getNodeReport(logger, id));
    elif (state == "close") :
        sendEmail(["rouble@gmail.com"], "[" + alarm_state + "] " + name + " is closed", getNodeReport(logger,id));

def main(id, state):
    processSignalOnSensor(id, state)
    return 0

if __name__=='__main__':
    sys.exit(main(sys.argv[1], sys.argv[2]))
