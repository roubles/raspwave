#!/usr/bin/env python
# @author rouble matta

import ConfigParser
import datetime
from CacheUtils import readStringValue, writeStringValue
from ConfUtils import getConfValue
from LoggerUtils import setupSecurityLogger
from RobotUtils import sendEmail

alarmStateKey = "ALARM_STATE"
alarmCodeKey  = "ALARM_CODE"

logger = setupSecurityLogger()

AlarmState = ["ARMED", "NOMOTION", "NOWAIT", "NOMOTIONNOWAIT", "DISARMED"]

def panic (info = None):
    # for now, just send an email.
    mailto = ["rouble@gmail.com"]
    subject = "Alarm! Alarm! Alarm!"
    body = "Alarm sounded at: " + str(datetime.datetime.now()) + "\n"
    if info is not None:
        body += info
    sendEmail(mailto, subject, body)

def unpanic (info = None):
    # for now, just send an email.
    mailto = ["rouble@gmail.com"]
    subject = "Alarm silenced!"
    body = "Alarm silenced at: " + str(datetime.datetime.now()) + "\n"
    if info is not None:
        body += info
    sendEmail(mailto, subject, body)

def getCurrentAlarmState ():
    try:
        return readStringValue(alarmStateKey)
    except KeyError:
        return "DISARMED"

def getCurrentAlarmCode ():
    try:
        return readStringValue(alarmCodeKey)
    except KeyError:
        return None

def setAlarmState(alarmState):
    if alarmState not in AlarmState:
        raise Exception("Unknown alarm state: " + alarmState)
    logger.info("Setting Alarm state to: " + alarmState)
    writeStringValue(alarmStateKey, alarmState)

def setAlarmCode(alarmCode):
    logger.info("Setting Alarm code to: " + alarmCode)
    writeStringValue(alarmCodeKey, alarmCode)

def getCurrentAlarmStateDelayForNode(id):
    return getAlarmStateDelayForNode(id, getCurrentState())

def getAlarmStateDelayForNode (id, alarmState):
    try:
        return getConfValue(id, alarmState + "_DELAY") 
    except ConfigParser.NoOptionError:
        return None
